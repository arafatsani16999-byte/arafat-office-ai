package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("bangla_voice_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"
        private const val KEY_MODEL_NAME = "selected_gemini_model"
        private const val KEY_TRANSCRIPTION_PROMPT = "custom_prompt_mode"
        const val DEFAULT_MODEL = "gemini-2.5-flash"
    }

    fun getEffectiveApiKey(): String {
        val customKey = prefs.getString(KEY_CUSTOM_API_KEY, "")?.trim() ?: ""
        if (customKey.isNotEmpty()) {
            return customKey
        }
        val buildKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
        if (buildKey.isNotEmpty() && buildKey != "MY_GEMINI_API_KEY") {
            return buildKey
        }
        return ""
    }

    fun getCustomApiKey(): String {
        return prefs.getString(KEY_CUSTOM_API_KEY, "") ?: ""
    }

    fun setCustomApiKey(key: String) {
        prefs.edit().putString(KEY_CUSTOM_API_KEY, key.trim()).apply()
    }

    fun hasValidApiKey(): Boolean {
        return getEffectiveApiKey().isNotEmpty()
    }

    fun getSelectedModel(): String {
        return prefs.getString(KEY_MODEL_NAME, DEFAULT_MODEL) ?: DEFAULT_MODEL
    }

    fun setSelectedModel(model: String) {
        prefs.edit().putString(KEY_MODEL_NAME, model).apply()
    }

    fun isUsingBuildConfigKey(): Boolean {
        val customKey = prefs.getString(KEY_CUSTOM_API_KEY, "")?.trim() ?: ""
        if (customKey.isNotEmpty()) return false
        val buildKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
        return buildKey.isNotEmpty() && buildKey != "MY_GEMINI_API_KEY"
    }
}
