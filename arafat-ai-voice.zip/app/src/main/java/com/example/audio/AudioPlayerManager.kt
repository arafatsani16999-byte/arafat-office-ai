package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class AudioPlayerManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private val coroutineScope = CoroutineScope(Dispatchers.Main)
    private var progressJob: Job? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0)
    val currentPositionMs: StateFlow<Int> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0)
    val durationMs: StateFlow<Int> = _durationMs.asStateFlow()

    fun playFile(file: File) {
        if (!file.exists()) return
        stop()
        try {
            val player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                start()
            }
            mediaPlayer = player
            _isPlaying.value = true
            _durationMs.value = player.duration.coerceAtLeast(1)
            _currentPositionMs.value = 0

            player.setOnCompletionListener {
                _isPlaying.value = false
                _currentPositionMs.value = 0
                stopProgressPolling()
            }

            startProgressPolling()
        } catch (e: Exception) {
            e.printStackTrace()
            _isPlaying.value = false
        }
    }

    fun playUri(uri: Uri) {
        stop()
        try {
            val player = MediaPlayer().apply {
                setDataSource(context, uri)
                prepare()
                start()
            }
            mediaPlayer = player
            _isPlaying.value = true
            _durationMs.value = player.duration.coerceAtLeast(1)
            _currentPositionMs.value = 0

            player.setOnCompletionListener {
                _isPlaying.value = false
                _currentPositionMs.value = 0
                stopProgressPolling()
            }

            startProgressPolling()
        } catch (e: Exception) {
            e.printStackTrace()
            _isPlaying.value = false
        }
    }

    fun togglePlayPause(file: File?) {
        val player = mediaPlayer
        if (player == null) {
            file?.let { playFile(it) }
            return
        }

        if (player.isPlaying) {
            player.pause()
            _isPlaying.value = false
            stopProgressPolling()
        } else {
            player.start()
            _isPlaying.value = true
            startProgressPolling()
        }
    }

    fun seekTo(positionMs: Int) {
        mediaPlayer?.let { player ->
            try {
                player.seekTo(positionMs)
                _currentPositionMs.value = positionMs
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun stop() {
        stopProgressPolling()
        mediaPlayer?.let { player ->
            try {
                if (player.isPlaying) {
                    player.stop()
                }
                player.reset()
                player.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        mediaPlayer = null
        _isPlaying.value = false
        _currentPositionMs.value = 0
    }

    private fun startProgressPolling() {
        stopProgressPolling()
        progressJob = coroutineScope.launch {
            while (isActive) {
                delay(200)
                mediaPlayer?.let { player ->
                    try {
                        if (player.isPlaying) {
                            _currentPositionMs.value = player.currentPosition
                            _durationMs.value = player.duration
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    private fun stopProgressPolling() {
        progressJob?.cancel()
        progressJob = null
    }

    fun release() {
        stop()
    }
}
