package com.example.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

enum class RecordingState {
    IDLE,
    RECORDING,
    PAUSED,
    COMPLETED
}

class AudioRecordingManager(private val context: Context) {
    private var mediaRecorder: MediaRecorder? = null
    private var currentOutputFile: File? = null

    private val _recordingState = MutableStateFlow(RecordingState.IDLE)
    val recordingState: StateFlow<RecordingState> = _recordingState.asStateFlow()

    private val _elapsedSeconds = MutableStateFlow(0)
    val elapsedSeconds: StateFlow<Int> = _elapsedSeconds.asStateFlow()

    private val _waveformAmplitudes = MutableStateFlow<List<Float>>(emptyList())
    val waveformAmplitudes: StateFlow<List<Float>> = _waveformAmplitudes.asStateFlow()

    private val coroutineScope = CoroutineScope(Dispatchers.Main)
    private var timerJob: Job? = null
    private var amplitudeJob: Job? = null

    fun startRecording(): File? {
        stopRecording()

        val file = File(
            context.cacheDir,
            "bangla_voice_${System.currentTimeMillis()}.m4a"
        )
        currentOutputFile = file

        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        try {
            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            _recordingState.value = RecordingState.RECORDING
            _elapsedSeconds.value = 0
            _waveformAmplitudes.value = emptyList()

            startPolling()
            return file
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                recorder.release()
            } catch (_: Exception) {}
            mediaRecorder = null
            _recordingState.value = RecordingState.IDLE
            return null
        }
    }

    fun pauseRecording() {
        if (_recordingState.value == RecordingState.RECORDING && mediaRecorder != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    mediaRecorder?.pause()
                    _recordingState.value = RecordingState.PAUSED
                    stopPolling()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun resumeRecording() {
        if (_recordingState.value == RecordingState.PAUSED && mediaRecorder != null) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    mediaRecorder?.resume()
                    _recordingState.value = RecordingState.RECORDING
                    startPolling()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun stopRecording(): File? {
        stopPolling()
        val file = currentOutputFile
        mediaRecorder?.let { recorder ->
            try {
                if (_recordingState.value == RecordingState.RECORDING || _recordingState.value == RecordingState.PAUSED) {
                    recorder.stop()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                try {
                    recorder.reset()
                    recorder.release()
                } catch (_: Exception) {}
            }
        }
        mediaRecorder = null
        if (file != null && file.exists() && file.length() > 0) {
            _recordingState.value = RecordingState.COMPLETED
            return file
        } else {
            _recordingState.value = RecordingState.IDLE
            return null
        }
    }

    fun reset() {
        stopRecording()
        _recordingState.value = RecordingState.IDLE
        _elapsedSeconds.value = 0
        _waveformAmplitudes.value = emptyList()
        currentOutputFile = null
    }

    private fun startPolling() {
        stopPolling()
        timerJob = coroutineScope.launch {
            while (isActive) {
                delay(1000)
                _elapsedSeconds.value += 1
            }
        }
        amplitudeJob = coroutineScope.launch {
            while (isActive) {
                delay(100)
                val amp = try {
                    mediaRecorder?.maxAmplitude ?: 0
                } catch (_: Exception) {
                    0
                }
                // Normalize 0..32767 to 0.05..1.0
                val normalized = (amp / 32767f).coerceIn(0.08f, 1.0f)
                val currentList = _waveformAmplitudes.value.toMutableList()
                if (currentList.size > 36) {
                    currentList.removeAt(0)
                }
                currentList.add(normalized)
                _waveformAmplitudes.value = currentList
            }
        }
    }

    private fun stopPolling() {
        timerJob?.cancel()
        timerJob = null
        amplitudeJob?.cancel()
        amplitudeJob = null
    }
}
