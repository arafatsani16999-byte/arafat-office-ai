package com.example.api

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

sealed class TranscriptionResult {
    data class Success(val text: String, val rawResponse: String? = null) : TranscriptionResult()
    data class Error(val message: String, val statusCode: Int? = null) : TranscriptionResult()
}

enum class TranscriptionPromptMode(val titleBn: String, val titleEn: String, val prompt: String) {
    CLEAN(
        titleBn = "বিশুদ্ধ বাংলা (ফিল্টার্ড)",
        titleEn = "Clean Bangla",
        prompt = "Transcribe this Bangla audio accurately into readable Bengali text. Clean up filler words while maintaining the original tone."
    ),
    VERBATIM(
        titleBn = "হুবহু প্রতিলিপিকরণ",
        titleEn = "Verbatim",
        prompt = "Transcribe this Bangla audio verbatim into accurate Bengali script exactly as spoken without omitting any repetitions or spoken words."
    ),
    WITH_ENGLISH(
        titleBn = "বাংলা ও ইংরেজি অনুবাদ",
        titleEn = "Bangla + English",
        prompt = "Transcribe this Bangla audio accurately into readable Bengali text. Clean up filler words while maintaining the original tone. Then provide a fluent English translation below under a clear 'English Translation:' header."
    ),
    SUMMARY(
        titleBn = "সারসংক্ষেপ ও মূল পয়েন্ট",
        titleEn = "Summary & Points",
        prompt = "Transcribe this Bangla audio into Bengali text and then provide a structured, concise summary with key takeaways and bullet points in Bengali."
    )
}

class GeminiTranscriber {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun transcribeAudio(
        apiKey: String,
        modelName: String,
        audioFile: File,
        mimeType: String = "audio/mp4",
        promptMode: TranscriptionPromptMode = TranscriptionPromptMode.CLEAN
    ): TranscriptionResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext TranscriptionResult.Error(
                "Gemini API কী পাওয়া যায়নি! অনুগ্রহ করে সেটিংস বাটনে ক্লিক করে আপনার Gemini API Key প্রবেশ করান।"
            )
        }

        if (!audioFile.exists() || audioFile.length() == 0L) {
            return@withContext TranscriptionResult.Error(
                "অডিও ফাইলটি খালি অথবা খুঁজে পাওয়া যায়নি। দয়া করে আবার রেকর্ড বা আপলোড করুন।"
            )
        }

        try {
            val audioBytes = audioFile.readBytes()
            val base64Data = Base64.encodeToString(audioBytes, Base64.NO_WRAP)

            val resolvedMimeType = when {
                mimeType.contains("mp3", ignoreCase = true) -> "audio/mp3"
                mimeType.contains("wav", ignoreCase = true) -> "audio/wav"
                mimeType.contains("m4a", ignoreCase = true) || mimeType.contains("mp4", ignoreCase = true) -> "audio/mp4"
                mimeType.contains("aac", ignoreCase = true) -> "audio/aac"
                mimeType.contains("ogg", ignoreCase = true) -> "audio/ogg"
                else -> "audio/mp4"
            }

            // Construct payload
            val root = JSONObject()
            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            // Text instruction part
            val textPart = JSONObject()
            textPart.put("text", promptMode.prompt)
            partsArray.put(textPart)

            // Audio data part
            val audioPart = JSONObject()
            val inlineData = JSONObject()
            inlineData.put("mimeType", resolvedMimeType)
            inlineData.put("data", base64Data)
            audioPart.put("inlineData", inlineData)
            partsArray.put(audioPart)

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            root.put("contents", contentsArray)

            // Generation config
            val genConfig = JSONObject()
            genConfig.put("temperature", 0.2)
            root.put("generationConfig", genConfig)

            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
            val requestBody = root.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(endpoint)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMsg = try {
                    val errorJson = JSONObject(responseBody)
                    val errorObj = errorJson.optJSONObject("error")
                    errorObj?.optString("message") ?: "HTTP ${response.code}: ${response.message}"
                } catch (e: Exception) {
                    "HTTP ${response.code}: ${response.message}"
                }
                return@withContext TranscriptionResult.Error(
                    message = "Gemini API ত্রুটি ($errorMsg)",
                    statusCode = response.code
                )
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                val promptFeedback = json.optJSONObject("promptFeedback")
                val blockReason = promptFeedback?.optString("blockReason")
                return@withContext TranscriptionResult.Error(
                    "কোন প্রতিলিপি পাওয়া যায়নি${if (blockReason != null) " (কারণ: $blockReason)" else ""}।"
                )
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            val stringBuilder = java.lang.StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val text = part.optString("text", "")
                    stringBuilder.append(text)
                }
            }

            val transcribedText = stringBuilder.toString().trim()
            if (transcribedText.isEmpty()) {
                return@withContext TranscriptionResult.Error("Gemini অডিও থেকে কোনো বাংলা টেক্সট উদ্ধার করতে পারেনি। অনুগ্রহ করে স্পষ্ট অডিও প্রদান করুন।")
            }

            TranscriptionResult.Success(transcribedText, responseBody)
        } catch (e: Exception) {
            TranscriptionResult.Error(
                "নেটওয়ার্ক বা প্রসেসিং ব্যর্থ হয়েছে: ${e.localizedMessage ?: e.javaClass.simpleName}"
            )
        }
    }

    suspend fun testConnection(apiKey: String, modelName: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject()
            val contents = JSONArray()
            val content = JSONObject()
            val parts = JSONArray()
            val part = JSONObject()
            part.put("text", "Say 'Bangla Voice Notes Ready'")
            parts.put(part)
            content.put("parts", parts)
            contents.put(content)
            root.put("contents", contents)

            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
            val requestBody = root.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url(endpoint).post(requestBody).build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (response.isSuccessful) {
                Result.success("সফলভাবে সংযোগ প্রতিষ্ঠিত হয়েছে! Gemini API প্রস্তুত।")
            } else {
                val errorMsg = try {
                    JSONObject(body).optJSONObject("error")?.optString("message") ?: response.message
                } catch (e: Exception) {
                    response.message
                }
                Result.failure(Exception("ত্রুটি ($errorMsg)"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
