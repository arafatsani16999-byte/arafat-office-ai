package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Teal / Emerald primary palette
val EmeraldPrimaryLight = Color(0xFF0D9488)
val EmeraldOnPrimaryLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFCCFBF1)
val EmeraldOnContainerLight = Color(0xFF115E59)

val EmeraldPrimaryDark = Color(0xFF2DD4BF)
val EmeraldOnPrimaryDark = Color(0xFF003833)
val EmeraldContainerDark = Color(0xFF134E4A)
val EmeraldOnContainerDark = Color(0xFF99F6E4)

// Indigo secondary palette
val IndigoSecondaryLight = Color(0xFF4F46E5)
val IndigoSecondaryDark = Color(0xFF818CF8)

// Surface & background
val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateSurfaceVariantLight = Color(0xFFF1F5F9)

val SlateBackgroundDark = Color(0xFF0B132B)
val SlateSurfaceDark = Color(0xFF111D38)
val SlateSurfaceVariantDark = Color(0xFF1C2D54)
