package com.example.ui

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiTranscriber
import com.example.api.TranscriptionPromptMode
import com.example.api.TranscriptionResult
import com.example.audio.AudioPlayerManager
import com.example.audio.AudioRecordingManager
import com.example.audio.BengaliTtsManager
import com.example.audio.RecordingState
import com.example.data.AppDatabase
import com.example.data.SettingsManager
import com.example.data.VoiceNote
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    val recordingManager = AudioRecordingManager(context)
    val playerManager = AudioPlayerManager(context)
    val ttsManager = BengaliTtsManager(context)
    val settingsManager = SettingsManager(context)
    private val transcriber = GeminiTranscriber()
    private val database = AppDatabase.getDatabase(context)
    private val voiceNoteDao = database.voiceNoteDao()

    // Database flow
    val savedNotes: StateFlow<List<VoiceNote>> = voiceNoteDao.getAllNotes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI States
    private val _activeTab = MutableStateFlow(0) // 0 = Record, 1 = Upload
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    private val _selectedAudioFile = MutableStateFlow<File?>(null)
    val selectedAudioFile: StateFlow<File?> = _selectedAudioFile.asStateFlow()

    private val _selectedAudioName = MutableStateFlow<String?>(null)
    val selectedAudioName: StateFlow<String?> = _selectedAudioName.asStateFlow()

    private val _selectedAudioMime = MutableStateFlow("audio/mp4")
    val selectedAudioMime: StateFlow<String> = _selectedAudioMime.asStateFlow()

    private val _isTranscribing = MutableStateFlow(false)
    val isTranscribing: StateFlow<Boolean> = _isTranscribing.asStateFlow()

    private val _transcriptionProgressStep = MutableStateFlow("")
    val transcriptionProgressStep: StateFlow<String> = _transcriptionProgressStep.asStateFlow()

    private val _transcribedText = MutableStateFlow("")
    val transcribedText: StateFlow<String> = _transcribedText.asStateFlow()

    private val _selectedPromptMode = MutableStateFlow(TranscriptionPromptMode.CLEAN)
    val selectedPromptMode: StateFlow<TranscriptionPromptMode> = _selectedPromptMode.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _infoMessage = MutableStateFlow<String?>(null)
    val infoMessage: StateFlow<String?> = _infoMessage.asStateFlow()

    private val _showSettingsDialog = MutableStateFlow(false)
    val showSettingsDialog: StateFlow<Boolean> = _showSettingsDialog.asStateFlow()

    private val _showHistorySheet = MutableStateFlow(false)
    val showHistorySheet: StateFlow<Boolean> = _showHistorySheet.asStateFlow()

    fun setActiveTab(index: Int) {
        _activeTab.value = index
    }

    fun setSelectedPromptMode(mode: TranscriptionPromptMode) {
        _selectedPromptMode.value = mode
    }

    fun updateTranscribedText(newText: String) {
        _transcribedText.value = newText
    }

    fun setShowSettingsDialog(show: Boolean) {
        _showSettingsDialog.value = show
    }

    fun setShowHistorySheet(show: Boolean) {
        _showHistorySheet.value = show
    }

    fun clearMessages() {
        _errorMessage.value = null
        _infoMessage.value = null
    }

    // Recording operations
    fun startRecording() {
        clearMessages()
        playerManager.stop()
        ttsManager.stop()
        val file = recordingManager.startRecording()
        if (file != null) {
            _selectedAudioFile.value = file
            _selectedAudioName.value = "ভয়েস রেকর্ড_${System.currentTimeMillis() % 10000}.m4a"
            _selectedAudioMime.value = "audio/mp4"
        } else {
            _errorMessage.value = "মাইক্রোফোন রেকর্ড শুরু করা সম্ভব হয়নি। পারমিশন চেক করুন।"
        }
    }

    fun pauseRecording() {
        recordingManager.pauseRecording()
    }

    fun resumeRecording() {
        recordingManager.resumeRecording()
    }

    fun stopRecording() {
        val file = recordingManager.stopRecording()
        if (file != null && file.exists() && file.length() > 0) {
            _selectedAudioFile.value = file
            _infoMessage.value = "রেকর্ডিং সম্পন্ন হয়েছে! এবার 'বাংলায় রূপান্তর' বাটনে ক্লিক করুন।"
        }
    }

    fun discardAudio() {
        playerManager.stop()
        ttsManager.stop()
        recordingManager.reset()
        _selectedAudioFile.value?.let { file ->
            try {
                if (file.name.startsWith("bangla_voice_")) {
                    file.delete()
                }
            } catch (_: Exception) {}
        }
        _selectedAudioFile.value = null
        _selectedAudioName.value = null
    }

    // Audio upload handling
    fun handleAudioPicked(uri: Uri, contentResolver: ContentResolver) {
        clearMessages()
        playerManager.stop()
        ttsManager.stop()
        recordingManager.reset()

        viewModelScope.launch(Dispatchers.IO) {
            try {
                var displayName = "অডিও ফাইল"
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        displayName = cursor.getString(nameIndex) ?: displayName
                    }
                }

                val mime = contentResolver.getType(uri) ?: when {
                    displayName.endsWith(".mp3", ignoreCase = true) -> "audio/mp3"
                    displayName.endsWith(".wav", ignoreCase = true) -> "audio/wav"
                    displayName.endsWith(".m4a", ignoreCase = true) -> "audio/mp4"
                    displayName.endsWith(".aac", ignoreCase = true) -> "audio/aac"
                    displayName.endsWith(".ogg", ignoreCase = true) -> "audio/ogg"
                    else -> "audio/mp4"
                }

                // Copy stream to temp cache file
                val extension = displayName.substringAfterLast('.', "m4a")
                val tempFile = File(context.cacheDir, "imported_${System.currentTimeMillis()}.$extension")
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        input.copyTo(output)
                    }
                }

                if (tempFile.exists() && tempFile.length() > 0) {
                    _selectedAudioFile.value = tempFile
                    _selectedAudioName.value = displayName
                    _selectedAudioMime.value = mime
                    _infoMessage.value = "অডিও ফাইল লোড হয়েছে: $displayName"
                } else {
                    _errorMessage.value = "অডিও ফাইলটি পড়া সম্ভব হয়নি।"
                }
            } catch (e: Exception) {
                _errorMessage.value = "ফাইল লোড করতে ব্যর্থ: ${e.localizedMessage}"
            }
        }
    }

    // Transcription
    fun transcribeCurrentAudio() {
        val audioFile = _selectedAudioFile.value
        if (audioFile == null || !audioFile.exists() || audioFile.length() == 0L) {
            _errorMessage.value = "অনুগ্রহ করে প্রথমে অডিও রেকর্ড করুন অথবা একটি অডিও ফাইল আপলোড করুন।"
            return
        }

        val apiKey = settingsManager.getEffectiveApiKey()
        if (apiKey.isBlank()) {
            _errorMessage.value = "Gemini API Key প্রয়োজন! অনুগ্রহ করে সেটিংস ওপেন করে API Key প্রদান করুন।"
            _showSettingsDialog.value = true
            return
        }

        playerManager.stop()
        ttsManager.stop()
        clearMessages()

        viewModelScope.launch {
            _isTranscribing.value = true
            _transcriptionProgressStep.value = "অডিও ডেটা প্রক্রিয়াকরণ করা হচ্ছে..."
            delay(400)

            _transcriptionProgressStep.value = "Google Gemini AI তে পাঠানো হচ্ছে..."
            val model = settingsManager.getSelectedModel()
            val mime = _selectedAudioMime.value
            val mode = _selectedPromptMode.value

            val result = transcriber.transcribeAudio(
                apiKey = apiKey,
                modelName = model,
                audioFile = audioFile,
                mimeType = mime,
                promptMode = mode
            )

            _isTranscribing.value = false
            _transcriptionProgressStep.value = ""

            when (result) {
                is TranscriptionResult.Success -> {
                    _transcribedText.value = result.text
                    _infoMessage.value = "সফলভাবে বাংলায় রূপান্তর সম্পন্ন হয়েছে!"
                }
                is TranscriptionResult.Error -> {
                    _errorMessage.value = result.message
                }
            }
        }
    }

    // Playback
    fun toggleAudioPlayback() {
        val file = _selectedAudioFile.value ?: return
        playerManager.togglePlayPause(file)
    }

    // TTS
    fun toggleTts() {
        val text = _transcribedText.value
        if (text.isBlank()) return
        if (ttsManager.isSpeaking.value) {
            ttsManager.stop()
        } else {
            ttsManager.speak(text)
        }
    }

    // Save Note to History
    fun saveCurrentNoteToHistory(customTitle: String? = null) {
        val text = _transcribedText.value
        if (text.isBlank()) {
            _errorMessage.value = "সংরক্ষণ করার মতো কোনো টেক্সট নেই।"
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            val title = if (!customTitle.isNullOrBlank()) {
                customTitle
            } else {
                val words = text.trim().split("\\s+".toRegex())
                words.take(5).joinToString(" ").take(30) + (if (words.size > 5) "..." else "")
            }

            val note = VoiceNote(
                title = title,
                transcribedText = text,
                timestamp = System.currentTimeMillis(),
                durationSeconds = recordingManager.elapsedSeconds.value,
                audioFileName = _selectedAudioName.value,
                transcriptionMode = _selectedPromptMode.value.titleBn
            )

            voiceNoteDao.insertNote(note)
            withContext(Dispatchers.Main) {
                _infoMessage.value = "ভয়েস নোট ইতিহাসে সংরক্ষিত হয়েছে!"
            }
        }
    }

    fun loadNoteToEditor(note: VoiceNote) {
        _transcribedText.value = note.transcribedText
        _infoMessage.value = "নোট লোড করা হয়েছে: ${note.title}"
        _showHistorySheet.value = false
    }

    fun deleteNote(note: VoiceNote) {
        viewModelScope.launch(Dispatchers.IO) {
            voiceNoteDao.deleteNote(note)
        }
    }

    fun clearAllNotes() {
        viewModelScope.launch(Dispatchers.IO) {
            voiceNoteDao.clearAll()
        }
    }

    fun clearTranscriptionOutput() {
        _transcribedText.value = ""
        ttsManager.stop()
        _infoMessage.value = "আউটপুট মুছে ফেলা হয়েছে।"
    }

    override fun onCleared() {
        super.onCleared()
        recordingManager.reset()
        playerManager.release()
        ttsManager.shutdown()
    }
}
