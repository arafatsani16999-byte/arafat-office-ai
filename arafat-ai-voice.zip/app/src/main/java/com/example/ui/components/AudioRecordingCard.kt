package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedIconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.RecordingState
import java.util.Locale

@Composable
fun AudioRecordingCard(
    recordingState: RecordingState,
    elapsedSeconds: Int,
    waveformAmplitudes: List<Float>,
    onStartRecording: () -> Unit,
    onPauseRecording: () -> Unit,
    onResumeRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onDiscardRecording: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Status Pill
            RecordingStatusPill(recordingState = recordingState)

            Spacer(modifier = Modifier.height(16.dp))

            // Timer
            val minutes = elapsedSeconds / 60
            val seconds = elapsedSeconds % 60
            val formattedTime = String.format(Locale.US, "%02d:%02d", minutes, seconds)

            Text(
                text = formattedTime,
                style = MaterialTheme.typography.displaySmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace
                ),
                color = if (recordingState == RecordingState.RECORDING) {
                    Color(0xFFEF4444)
                } else {
                    MaterialTheme.colorScheme.onSurface
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Waveform visualizer
            WaveformVisualizer(
                amplitudes = waveformAmplitudes,
                recordingState = recordingState,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Discard Button (visible during recording/paused or completed)
                AnimatedVisibility(
                    visible = recordingState != RecordingState.IDLE
                ) {
                    OutlinedIconButton(
                        onClick = onDiscardRecording,
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("discard_recording_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Discard recording",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }

                if (recordingState != RecordingState.IDLE) {
                    Spacer(modifier = Modifier.width(20.dp))
                }

                // Main Record / Action Button with animated pulse
                RecordMainButton(
                    recordingState = recordingState,
                    onStartRecording = onStartRecording,
                    onStopRecording = onStopRecording
                )

                // Pause / Resume Button (visible while recording or paused)
                AnimatedVisibility(
                    visible = recordingState == RecordingState.RECORDING || recordingState == RecordingState.PAUSED
                ) {
                    Spacer(modifier = Modifier.width(20.dp))
                    FilledIconButton(
                        onClick = {
                            if (recordingState == RecordingState.RECORDING) {
                                onPauseRecording()
                            } else {
                                onResumeRecording()
                            }
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("pause_resume_button"),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    ) {
                        Icon(
                            imageVector = if (recordingState == RecordingState.RECORDING) {
                                Icons.Default.Pause
                            } else {
                                Icons.Default.PlayArrow
                            },
                            contentDescription = if (recordingState == RecordingState.RECORDING) "Pause" else "Resume"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = when (recordingState) {
                    RecordingState.IDLE -> "মাইক্রোফোন বাটন স্পর্শ করে রেকর্ডিং শুরু করুন"
                    RecordingState.RECORDING -> "রেকর্ডিং থামাতে লাল স্কয়ার বাটনে চাপুন"
                    RecordingState.PAUSED -> "রেকর্ডিং সাময়িক স্থগিত করা হয়েছে"
                    RecordingState.COMPLETED -> "রেকর্ডিং সম্পন্ন! নিচে রূপান্তর বাটনে চাপুন"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun RecordMainButton(
    recordingState: RecordingState,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulseRing")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(
        contentAlignment = Alignment.Center
    ) {
        if (recordingState == RecordingState.RECORDING) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(Color(0xFFEF4444).copy(alpha = 0.25f))
            )
        }

        FilledIconButton(
            onClick = {
                when (recordingState) {
                    RecordingState.IDLE -> onStartRecording()
                    RecordingState.RECORDING, RecordingState.PAUSED -> onStopRecording()
                    RecordingState.COMPLETED -> onStartRecording()
                }
            },
            modifier = Modifier
                .size(68.dp)
                .testTag("record_toggle_button"),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = when (recordingState) {
                    RecordingState.RECORDING -> Color(0xFFDC2626)
                    RecordingState.PAUSED -> Color(0xFFF59E0B)
                    else -> MaterialTheme.colorScheme.primary
                },
                contentColor = Color.White
            )
        ) {
            Icon(
                imageVector = when (recordingState) {
                    RecordingState.RECORDING, RecordingState.PAUSED -> Icons.Default.Stop
                    else -> Icons.Default.Mic
                },
                contentDescription = if (recordingState == RecordingState.RECORDING) "Stop recording" else "Start recording",
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

@Composable
private fun RecordingStatusPill(recordingState: RecordingState) {
    val (statusText, pillColor, textColor) = when (recordingState) {
        RecordingState.IDLE -> Triple("প্রস্তুত", Color(0xFF64748B), Color(0xFF64748B))
        RecordingState.RECORDING -> Triple("রেকর্ডিং চলছে...", Color(0xFFEF4444), Color(0xFFDC2626))
        RecordingState.PAUSED -> Triple("বিরতি আছে", Color(0xFFF59E0B), Color(0xFFD97706))
        RecordingState.COMPLETED -> Triple("রেকর্ডিং সম্পন্ন", Color(0xFF10B981), Color(0xFF059669))
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = pillColor.copy(alpha = 0.12f),
        modifier = Modifier.border(1.dp, pillColor.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(pillColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = statusText,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = textColor
            )
        }
    }
}
