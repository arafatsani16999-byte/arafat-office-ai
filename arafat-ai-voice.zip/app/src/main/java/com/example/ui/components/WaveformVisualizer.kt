package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.audio.RecordingState
import kotlin.math.sin

@Composable
fun WaveformVisualizer(
    amplitudes: List<Float>,
    recordingState: RecordingState,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAnim by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAnim"
    )

    val barCount = 28
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.tertiary

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(72.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(0.92f),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 0 until barCount) {
                val heightFraction: Float = when (recordingState) {
                    RecordingState.RECORDING -> {
                        val ampIndex = amplitudes.size - (barCount - i)
                        if (ampIndex >= 0 && ampIndex < amplitudes.size) {
                            amplitudes[ampIndex].coerceIn(0.12f, 1.0f)
                        } else {
                            val wave = (sin((i.toDouble() + pulseAnim * 6)) * 0.35 + 0.4).toFloat()
                            wave.coerceIn(0.12f, 0.95f)
                        }
                    }
                    RecordingState.PAUSED -> {
                        0.18f
                    }
                    RecordingState.COMPLETED -> {
                        val wave = (sin(i.toDouble() * 0.45) * 0.3 + 0.45).toFloat()
                        wave.coerceIn(0.15f, 0.85f)
                    }
                    RecordingState.IDLE -> {
                        0.12f
                    }
                }

                val barBrush = Brush.verticalGradient(
                    colors = if (recordingState == RecordingState.RECORDING) {
                        listOf(Color(0xFFEF4444), Color(0xFFF97316))
                    } else {
                        listOf(primaryColor, secondaryColor)
                    }
                )

                Box(
                    modifier = Modifier
                        .width(4.5.dp)
                        .height((56 * heightFraction).coerceAtLeast(6f).dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(barBrush)
                )
            }
        }
    }
}
