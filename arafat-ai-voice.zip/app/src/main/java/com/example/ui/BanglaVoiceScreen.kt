package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.api.TranscriptionPromptMode
import com.example.audio.RecordingState
import com.example.ui.components.AudioPlayerBar
import com.example.ui.components.AudioRecordingCard
import com.example.ui.components.AudioUploadCard
import com.example.ui.components.HistoryBottomSheet
import com.example.ui.components.SettingsDialog
import com.example.ui.components.TranscriptionOutputCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BanglaVoiceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Collect States
    val activeTab by viewModel.activeTab.collectAsState()
    val recordingState by viewModel.recordingManager.recordingState.collectAsState()
    val elapsedSeconds by viewModel.recordingManager.elapsedSeconds.collectAsState()
    val waveformAmplitudes by viewModel.recordingManager.waveformAmplitudes.collectAsState()

    val selectedAudioFile by viewModel.selectedAudioFile.collectAsState()
    val selectedAudioName by viewModel.selectedAudioName.collectAsState()

    val isPlaying by viewModel.playerManager.isPlaying.collectAsState()
    val currentPositionMs by viewModel.playerManager.currentPositionMs.collectAsState()
    val durationMs by viewModel.playerManager.durationMs.collectAsState()

    val isSpeaking by viewModel.ttsManager.isSpeaking.collectAsState()

    val isTranscribing by viewModel.isTranscribing.collectAsState()
    val progressStep by viewModel.transcriptionProgressStep.collectAsState()
    val transcribedText by viewModel.transcribedText.collectAsState()
    val selectedPromptMode by viewModel.selectedPromptMode.collectAsState()

    val errorMessage by viewModel.errorMessage.collectAsState()
    val infoMessage by viewModel.infoMessage.collectAsState()

    val showSettingsDialog by viewModel.showSettingsDialog.collectAsState()
    val showHistorySheet by viewModel.showHistorySheet.collectAsState()
    val savedNotes by viewModel.savedNotes.collectAsState()

    var showSaveNoteDialog by remember { mutableStateOf(false) }
    var saveNoteTitleInput by remember { mutableStateOf("") }

    // Audio recording permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startRecording()
        } else {
            Toast.makeText(
                context,
                "মাইক্রোফোন অনুমতি ছাড়া অডিও রেকর্ড করা সম্ভব নয়",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun checkAndRequestRecord() {
        val permissionCheck = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        )
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            viewModel.startRecording()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Handle Snackbars
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessages()
        }
    }

    LaunchedEffect(infoMessage) {
        infoMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessages()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "বাংলা ভয়েস টু টেক্সট",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Bangla Voice Notes by Gemini AI",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    // API Key Status Chip
                    val hasKey = viewModel.settingsManager.hasValidApiKey()
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (hasKey) Color(0xFF10B981).copy(alpha = 0.14f) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                        modifier = Modifier
                            .clickable { viewModel.setShowSettingsDialog(true) }
                            .padding(end = 4.dp)
                            .testTag("api_key_status_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (hasKey) Icons.Default.Key else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (hasKey) Color(0xFF047857) else MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (hasKey) "API Ready" else "Key Required",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (hasKey) Color(0xFF047857) else MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    // History Button
                    IconButton(
                        onClick = { viewModel.setShowHistorySheet(true) },
                        modifier = Modifier.testTag("history_button")
                    ) {
                        if (savedNotes.isNotEmpty()) {
                            BadgedBox(
                                badge = {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${savedNotes.size}",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                ),
                                                color = MaterialTheme.colorScheme.onPrimary
                                            )
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.History, contentDescription = "Saved Notes History")
                            }
                        } else {
                            Icon(Icons.Default.History, contentDescription = "Saved Notes History")
                        }
                    }

                    // Settings Button
                    IconButton(
                        onClick = { viewModel.setShowSettingsDialog(true) },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Tabs: Record Audio vs Upload Audio
                TabRow(
                    selectedTabIndex = activeTab,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .testTag("input_mode_tabrow"),
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    indicator = {}
                ) {
                    Tab(
                        selected = activeTab == 0,
                        onClick = { viewModel.setActiveTab(0) },
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (activeTab == 0) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                            )
                            .testTag("tab_record"),
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = if (activeTab == 0) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ভয়েস রেকর্ড",
                                    fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Normal,
                                    color = if (activeTab == 0) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    )
                    Tab(
                        selected = activeTab == 1,
                        onClick = { viewModel.setActiveTab(1) },
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (activeTab == 1) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                            )
                            .testTag("tab_upload"),
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CloudUpload,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = if (activeTab == 1) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "অডিও ফাইল",
                                    fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Normal,
                                    color = if (activeTab == 1) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Input Content based on Tab
                if (activeTab == 0) {
                    AudioRecordingCard(
                        recordingState = recordingState,
                        elapsedSeconds = elapsedSeconds,
                        waveformAmplitudes = waveformAmplitudes,
                        onStartRecording = { checkAndRequestRecord() },
                        onPauseRecording = { viewModel.pauseRecording() },
                        onResumeRecording = { viewModel.resumeRecording() },
                        onStopRecording = { viewModel.stopRecording() },
                        onDiscardRecording = { viewModel.discardAudio() }
                    )
                } else {
                    AudioUploadCard(
                        selectedFile = selectedAudioFile,
                        selectedFileName = selectedAudioName,
                        onAudioFilePicked = { uri ->
                            viewModel.handleAudioPicked(uri, context.contentResolver)
                        },
                        onDiscardFile = { viewModel.discardAudio() }
                    )
                }

                // Audio Playback Preview Bar (visible whenever an audio file is ready)
                AnimatedVisibility(
                    visible = selectedAudioFile != null && recordingState != RecordingState.RECORDING,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Column {
                        Spacer(modifier = Modifier.height(14.dp))
                        AudioPlayerBar(
                            isPlaying = isPlaying,
                            currentPositionMs = currentPositionMs,
                            durationMs = durationMs,
                            onTogglePlayPause = { viewModel.toggleAudioPlayback() },
                            onSeek = { viewModel.playerManager.seekTo(it) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Prompt Modes Chip Row
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Text(
                            text = "রূপান্তর মোড (Transcription Style):",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TranscriptionPromptMode.values().forEach { mode ->
                                FilterChip(
                                    selected = selectedPromptMode == mode,
                                    onClick = { viewModel.setSelectedPromptMode(mode) },
                                    label = {
                                        Text(
                                            text = mode.titleEn,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Convert with Gemini Action Button
                val canTranscribe = selectedAudioFile != null &&
                        recordingState != RecordingState.RECORDING &&
                        !isTranscribing

                Button(
                    onClick = { viewModel.transcribeCurrentAudio() },
                    enabled = canTranscribe,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("transcribe_gemini_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    if (isTranscribing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "বাংলায় রূপান্তর হচ্ছে...",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Gemini AI দিয়ে বাংলায় রূপান্তর করুন",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                // Transcribing Progress Status
                AnimatedVisibility(visible = isTranscribing) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = progressStep.ifEmpty { "প্রক্রিয়াধীন..." },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Output Display Area
                TranscriptionOutputCard(
                    transcribedText = transcribedText,
                    onTextChange = { viewModel.updateTranscribedText(it) },
                    onSaveToHistory = {
                        saveNoteTitleInput = ""
                        showSaveNoteDialog = true
                    },
                    onClear = { viewModel.clearTranscriptionOutput() },
                    isSpeaking = isSpeaking,
                    onToggleTts = { viewModel.toggleTts() }
                )

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    // Dialogs
    if (showSettingsDialog) {
        SettingsDialog(
            settingsManager = viewModel.settingsManager,
            onDismiss = { viewModel.setShowSettingsDialog(false) }
        )
    }

    if (showHistorySheet) {
        HistoryBottomSheet(
            notes = savedNotes,
            onSelectNote = { note -> viewModel.loadNoteToEditor(note) },
            onDeleteNote = { note -> viewModel.deleteNote(note) },
            onClearAllNotes = { viewModel.clearAllNotes() },
            onDismiss = { viewModel.setShowHistorySheet(false) }
        )
    }

    if (showSaveNoteDialog) {
        AlertDialog(
            onDismissRequest = { showSaveNoteDialog = false },
            title = { Text("নোট সংরক্ষণ করুন") },
            text = {
                Column {
                    Text("ভয়েস নোটের জন্য একটি নাম লিখুন (ঐচ্ছিক):")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = saveNoteTitleInput,
                        onValueChange = { saveNoteTitleInput = it },
                        placeholder = { Text("যেমন: মিটিং আলোচনা, বক্তৃতার অংশ...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveCurrentNoteToHistory(saveNoteTitleInput.trim().ifEmpty { null })
                        showSaveNoteDialog = false
                    }
                ) {
                    Text("সংরক্ষণ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveNoteDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}
